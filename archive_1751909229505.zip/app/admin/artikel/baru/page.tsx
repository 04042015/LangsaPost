import { ArticleForm } from "@/components/admin/article-form"

export default function NewArticlePage() {
  return <ArticleForm />
}
